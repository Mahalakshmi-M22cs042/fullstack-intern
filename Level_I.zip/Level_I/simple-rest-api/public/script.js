const API = "/users";

// Load users automatically
window.onload = getUsers;

// ========================
// GET USERS
// ========================
async function getUsers() {

    try {

        const response = await fetch(API);

        const users = await response.json();

        document.getElementById("totalUsers")
            .textContent = users.length;

        const container =
            document.getElementById("users");

        container.innerHTML = "";

        if (users.length === 0) {

            container.innerHTML = `
                <div class="user-card">
                    <h3>No Users Found</h3>
                </div>
            `;

            return;
        }

        users.forEach(user => {

            container.innerHTML += `

                <div class="user-card">

                    <h3>
                        👤 ${user.name}
                    </h3>

                    <p>
                        📧 ${user.email}
                    </p>

                    <div class="actions">

                        <button
                            class="edit"
                            onclick="editUser(
                                '${user.id}',
                                '${user.name}',
                                '${user.email}'
                            )">

                            ✏ Edit

                        </button>

                        <button
                            class="delete"
                            onclick="deleteUser(${user.id})">

                            🗑 Delete

                        </button>

                    </div>

                </div>

            `;
        });

    } catch (error) {

        console.error(error);

        document.getElementById("users").innerHTML = `
            <div class="user-card">
                <h3>❌ Failed To Load Users</h3>
            </div>
        `;
    }
}

// ========================
// SAVE USER
// ========================
async function saveUser() {

    const id =
        document.getElementById("userId").value;

    const name =
        document.getElementById("name").value.trim();

    const email =
        document.getElementById("email").value.trim();

    if (!name || !email) {

        alert("Please fill all fields");

        return;
    }

    try {

        if (id) {

            await fetch(`${API}/${id}`, {

                method: "PUT",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    name,
                    email
                })

            });

        } else {

            await fetch(API, {

                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    name,
                    email
                })

            });
        }

        clearForm();

        getUsers();

    } catch (error) {

        console.error(error);

        alert("Error saving user");
    }
}

// ========================
// EDIT USER
// ========================
function editUser(
    id,
    name,
    email
) {

    document.getElementById("userId").value = id;

    document.getElementById("name").value = name;

    document.getElementById("email").value = email;

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

// ========================
// DELETE USER
// ========================
async function deleteUser(id) {

    const confirmDelete =
        confirm("Delete this user?");

    if (!confirmDelete)
        return;

    try {

        await fetch(`${API}/${id}`, {
            method: "DELETE"
        });

        getUsers();

    } catch (error) {

        console.error(error);

        alert("Delete failed");
    }
}

// ========================
// CLEAR FORM
// ========================
function clearForm() {

    document.getElementById("userId").value = "";

    document.getElementById("name").value = "";

    document.getElementById("email").value = "";
}