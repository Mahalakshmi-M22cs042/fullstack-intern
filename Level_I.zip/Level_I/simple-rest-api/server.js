const express = require("express");
const app = express();

app.use(express.json());
app.use(express.static("public"));

const PORT = 3000;

let users = [
  {
    id: 1,
    name: "Mahalakshmi",
    email: "maha@gmail.com"
  }
];

// GET ALL USERS
app.get("/users", (req, res) => {
  res.json(users);
});

// GET USER BY ID
app.get("/users/:id", (req, res) => {
  const user = users.find(
    u => u.id === parseInt(req.params.id)
  );

  if (!user) {
    return res.status(404).json({
      message: "User not found"
    });
  }

  res.json(user);
});

// CREATE USER
app.post("/users", (req, res) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.status(400).json({
      message: "Name and Email required"
    });
  }

  const newUser = {
    id: Date.now(),
    name,
    email
  };

  users.push(newUser);

  res.status(201).json(newUser);
});

// UPDATE USER
app.put("/users/:id", (req, res) => {
  const user = users.find(
    u => u.id === parseInt(req.params.id)
  );

  if (!user) {
    return res.status(404).json({
      message: "User not found"
    });
  }

  user.name = req.body.name;
  user.email = req.body.email;

  res.json(user);
});

// DELETE USER
app.delete("/users/:id", (req, res) => {
  users = users.filter(
    u => u.id !== parseInt(req.params.id)
  );

  res.json({
    message: "User deleted successfully"
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Server Running`);
  console.log(`🌐 http://localhost:${PORT}`);
});